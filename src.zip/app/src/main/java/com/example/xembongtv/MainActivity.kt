package com.example.xembongtv

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.app.PictureInPictureParams
import android.util.Rational
import android.view.TextureView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator
import com.bumptech.glide.Glide
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap

// ======================================================================================
//  XEM BÓNG TV - bản riêng cho Android TV (điều khiển hoàn toàn bằng remote)
//  Màn hình 1: lưới các trận (đọc từ trang chủ). Màn hình 2: trang xem trận.
// ======================================================================================

data class Match(
    val url: String,
    val home: String,
    val away: String,
    val homeLogo: String,
    val awayLogo: String,
    val league: String,
    val live: Boolean,
    val score: String,
    val minute: String,
    val time: String,
    val providers: List<Pair<String, String>>
)

class MatchVH(
    val card: LinearLayout,
    val league: TextView,
    val homeLogo: ImageView,
    val awayLogo: ImageView,
    val mid: TextView,
    val homeName: TextView,
    val awayName: TextView,
    val status: TextView
) : RecyclerView.ViewHolder(card)

class CursorView(ctx: Context, private val size: Float) : View(ctx) {
    var cx = 0f
    var cy = 0f
    var placed = false
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = size * 0.09f
    }
    private val path = Path()

    fun center() {
        cx = width / 2f
        cy = height / 2f
        placed = true
        invalidate()
    }

    fun moveBy(dx: Int, dy: Int) {
        cx = (cx + dx).coerceIn(0f, width.toFloat())
        cy = (cy + dy).coerceIn(0f, height.toFloat())
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!placed) return
        path.reset()
        path.moveTo(cx, cy)
        path.lineTo(cx, cy + size)
        path.lineTo(cx + size * 0.25f, cy + size * 0.78f)
        path.lineTo(cx + size * 0.42f, cy + size * 1.15f)
        path.lineTo(cx + size * 0.56f, cy + size * 1.08f)
        path.lineTo(cx + size * 0.40f, cy + size * 0.72f)
        path.lineTo(cx + size * 0.72f, cy + size * 0.72f)
        path.close()
        canvas.drawPath(path, fill)
        canvas.drawPath(path, line)
    }
}

class BallLoaderView(ctx: Context) : View(ctx) {
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B2333"); style = Paint.Style.FILL }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#9FB3D1"); style = Paint.Style.STROKE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#55000000"); style = Paint.Style.FILL }
    private val grass = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2E9E5B"); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val clip = Path()
    private val pent = Path()
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 850
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    fun start() {
        if (!anim.isRunning) anim.start()
    }

    fun stop() {
        anim.cancel()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    private fun pentagon(cx: Float, cy: Float, r: Float, rot: Float) {
        pent.reset()
        for (i in 0 until 5) {
            val a = Math.toRadians((rot + i * 72.0 - 90.0))
            val x = cx + (r * Math.cos(a)).toFloat()
            val y = cy + (r * Math.sin(a)).toFloat()
            if (i == 0) pent.moveTo(x, y) else pent.lineTo(x, y)
        }
        pent.close()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = minOf(w, h) * 0.17f
        val groundY = h * 0.88f
        val k = 2f * t - 1f
        val p = 1f - k * k                       // 0 chạm đất, 1 ở đỉnh
        val cx = w / 2f
        val cy = groundY - r - p * h * 0.55f

        grass.strokeWidth = r * 0.16f
        canvas.drawLine(w * 0.15f, groundY, w * 0.85f, groundY, grass)

        val sr = r * (1.05f - 0.5f * p)
        canvas.drawOval(cx - sr, groundY - r * 0.14f, cx + sr, groundY + r * 0.14f, shadow)

        canvas.save()
        clip.reset()
        clip.addCircle(cx, cy, r, Path.Direction.CW)
        canvas.clipPath(clip)
        canvas.drawCircle(cx, cy, r, white)
        val rot = t * 360f * 1.5f
        canvas.save()
        canvas.rotate(rot, cx, cy)
        pentagon(cx, cy, r * 0.40f, 0f)
        canvas.drawPath(pent, dark)
        for (i in 0 until 5) {
            val a = Math.toRadians(i * 72.0 - 90.0)
            val px = cx + (r * 0.92 * Math.cos(a)).toFloat()
            val py = cy + (r * 0.92 * Math.sin(a)).toFloat()
            pentagon(px, py, r * 0.30f, (i * 72f) + 36f)
            canvas.drawPath(pent, dark)
        }
        canvas.restore()
        canvas.restore()
        rim.strokeWidth = r * 0.07f
        canvas.drawCircle(cx, cy, r, rim)
    }
}

class MainActivity : AppCompatActivity() {

    companion object {
        // Trang chủ mặc định (có thể đổi ngay trong app: nút xanh lá -> Đổi địa chỉ web)
        const val HOME_URL = "https://gavangtvttbdi.tv/"
        const val MOVIE_URL = "https://www.500phim.net/"

        // Tên miền được phép mở. Tên miền có chữ "gavang" và tên miền trang đang dùng luôn được phép.
        val EXTRA_ALLOWED_HOSTS: List<String> = listOf()

        const val IMG_UA = "Mozilla/5.0 (Linux; Android 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"

        // đoạn JS tìm thẻ video (kể cả trong iframe cùng nguồn)
        const val JS_FIND = "function f(d){var v=d.querySelector('video');if(v)return v;" +
            "var fr=d.querySelectorAll('iframe');for(var i=0;i<fr.length;i++){try{var x=f(fr[i].contentDocument);if(x)return x}catch(e){}}return null}"
    }

    private enum class Mode { HOME, GRID, WEB }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var scraper: WebView
    private lateinit var gridLayer: LinearLayout
    private lateinit var recycler: RecyclerView
    private lateinit var infoText: TextView
    private lateinit var msgBox: LinearLayout
    private lateinit var msgText: TextView
    private lateinit var retryBtn: Button
    private lateinit var origBtn: Button
    private lateinit var cursor: CursorView
    private lateinit var shell: WebView
    private lateinit var tvView: TextureView
    private lateinit var homeBtn: TextView
    private lateinit var ballLoader: BallLoaderView
    private lateinit var webLoading: LinearLayout
    private lateinit var webBall: BallLoaderView
    private val hideWebLoading = Runnable { setWebLoading(false) }
    private var scrapeEarly = false
    private var tvUrl = ""
    private var tvRef = ""
    private var tvUa = ""
    private var tvAttempt = 0
    private var exo: ExoPlayer? = null
    private var siteKind = "ball"
    private var movieUrl = MOVIE_URL
    private var movieHost = ""
    private var movieInjectJs = ""
    private var playerActive = false
    private var backLongHandled = false
    private val isTv by lazy { packageManager.hasSystemFeature("android.software.leanback") }
    private val fadeHome = Runnable { homeBtn.animate().alpha(0.3f).setDuration(400).start() }

    private val matchAdapter = MatchAdapter()
    private val ui = Handler(Looper.getMainLooper())

    private var chrome: WebChromeClient? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    private var mode = Mode.HOME
    private var origSite = false
    private var cursorOn = true
    private var lastPos = 0
    private var okLongHandled = false

    private var unit = 2f
    private var homeUrl = HOME_URL
    private var homeHost = ""
    private var adBlock = true
    private var injectJs = ""
    private var scrapeJs = ""
    private var scrapeGen = 0
    private var scrapeAttempt = 0
    private var seekWarned = false

    @Volatile private var adHosts: HashSet<String> = HashSet()
    @Volatile private var adHostsReady = false
    private val seenHosts = ConcurrentHashMap<String, Int>()
    private val seenBlocked = ConcurrentHashMap<String, Boolean>()
    private val dynAllowed = ConcurrentHashMap<String, Boolean>()

    // ------------------------------------------------------------------ vòng đời
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLog()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        unit = (resources.displayMetrics.heightPixels / 540f).coerceAtLeast(1f)

        val saved = prefs().getString("home_url", null)
        homeUrl = if (!saved.isNullOrBlank()) saved else HOME_URL
        homeHost = hostOf(homeUrl)
        val savedMovie = prefs().getString("movie_url", null)
        movieUrl = if (!savedMovie.isNullOrBlank()) savedMovie else MOVIE_URL
        movieHost = hostOf(movieUrl)

        injectJs = readAsset("inject.js")
        scrapeJs = readAsset("scrape.js")
        movieInjectJs = readAsset("movie_inject.js")
        loadAdHosts()

        buildUi()
        setupWebViews()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })

        hideBars()
        shell.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        hideBars()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        root.removeAllViews()
        exo?.release()
        exo = null
        shell.destroy()
        web.destroy()
        scraper.destroy()
        super.onDestroy()
    }

    private fun hideBars() {
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
    }

    // ------------------------------------------------------------------ giao diện
    private fun buildUi() {
        val bg = Color.parseColor("#0B0F17")
        root = FrameLayout(this).apply { setBackgroundColor(bg) }

        // WebView ẩn dùng để đọc danh sách trận
        scraper = WebView(this).apply { visibility = View.INVISIBLE }
        root.addView(scraper, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // WebView xem trận
        web = WebView(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
            keepScreenOn = true
        }
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // lớp lưới trận
        gridLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(px(40), px(22), px(40), px(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleView = TextView(this).apply {
            text = "XEM BÓNG"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 30f * unit)
        }
        infoText = TextView(this).apply {
            setTextColor(Color.parseColor("#8FA3BF"))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 14f * unit)
            gravity = Gravity.END
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(infoText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        gridLayer.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        recycler = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 3)
            adapter = matchAdapter
            clipToPadding = false
            itemAnimator = null
            setPadding(0, px(12), 0, px(12))
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }
        gridLayer.addView(recycler, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val hint = TextView(this).apply {
            text = "OK: xem trận     Xanh lá: menu     Vàng: tải lại     Xanh dương (hoặc giữ OK): nguồn phát khác     Số 1-9: nhảy tới trận"
            setTextColor(Color.parseColor("#6F829E"))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 12f * unit)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        gridLayer.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(gridLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        gridLayer.visibility = View.GONE

        // hộp thông báo giữa màn hình (đang tải / lỗi)
        msgBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(px(80), px(40), px(80), px(40))
            visibility = View.GONE
        }
        msgText = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 18f * unit)
            gravity = Gravity.CENTER
        }
        retryBtn = Button(this).apply {
            text = "Tải lại danh sách"
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 16f * unit)
            setOnClickListener { reloadMatches() }
        }
        origBtn = Button(this).apply {
            text = "Mở trang web gốc (dùng con trỏ)"
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 16f * unit)
            setOnClickListener { enterWeb(homeUrl, true) }
        }
        ballLoader = BallLoaderView(this)
        msgBox.addView(ballLoader, LinearLayout.LayoutParams(px(190), px(170)))
        msgBox.addView(msgText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val bl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bl.topMargin = px(20)
        msgBox.addView(retryBtn, bl)
        val bl2 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bl2.topMargin = px(10)
        msgBox.addView(origBtn, bl2)
        root.addView(msgBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // màn hình chờ khi mở một trận: quả bóng nảy
        webLoading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            visibility = View.GONE
            isClickable = true
        }
        webBall = BallLoaderView(this)
        webLoading.addView(webBall, LinearLayout.LayoutParams(px(190), px(170)))
        val wl = TextView(this).apply {
            text = "Đang vào trận…"
            setTextColor(Color.parseColor("#8FA3BF"))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 16f * unit)
            gravity = Gravity.CENTER
        }
        webLoading.addView(wl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(webLoading, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // màn hình phát kênh TV (ExoPlayer) nằm dưới giao diện chính
        tvView = TextureView(this).apply { visibility = View.GONE }
        root.addView(tvView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))

        // giao diện chính: màn hình chính + Xem TV
        shell = WebView(this).apply { setBackgroundColor(bg) }
        root.addView(shell, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // con trỏ ảo
        cursor = CursorView(this, 26f * unit).apply {
            visibility = View.GONE
            isFocusable = false
        }
        root.addView(cursor, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // nút về màn hình chính (hiện khi đang ở Xem bóng / Xem phim)
        homeBtn = TextView(this).apply {
            text = "Màn hình chính"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 13f * unit)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(px(14), px(8), px(14), px(8))
            background = chipBackground(Color.parseColor("#CC121927"))
            isFocusable = false
            visibility = View.GONE
            setOnClickListener { goHome() }
        }
        val hlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        hlp.topMargin = px(10)
        hlp.rightMargin = px(10)
        root.addView(homeBtn, hlp)

        setContentView(root)
    }

    // ------------------------------------------------------------------ danh sách trận (lưới)
    inner class MatchAdapter : RecyclerView.Adapter<MatchVH>() {
        var items: List<Match> = emptyList()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MatchVH {
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(px(14), px(12), px(14), px(12))
                isFocusable = true
                isClickable = true
                isLongClickable = true
                background = cardBackground()
                val lp = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.setMargins(px(8), px(8), px(8), px(8))
                layoutParams = lp
                setOnFocusChangeListener { v, has ->
                    v.animate().scaleX(if (has) 1.06f else 1f).scaleY(if (has) 1.06f else 1f).setDuration(120).start()
                    v.translationZ = if (has) 20f else 0f
                }
            }
            val league = TextView(this@MainActivity).apply {
                setTextColor(Color.parseColor("#8FA3BF"))
                setTextSize(TypedValue.COMPLEX_UNIT_PX, 11f * unit)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }
            card.addView(league, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            val homeLogo = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            val awayLogo = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            val mid = TextView(this@MainActivity).apply {
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setTextSize(TypedValue.COMPLEX_UNIT_PX, 24f * unit)
                gravity = Gravity.CENTER
                minWidth = px(80)
            }
            row.addView(homeLogo, LinearLayout.LayoutParams(px(54), px(54)))
            row.addView(mid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(awayLogo, LinearLayout.LayoutParams(px(54), px(54)))
            val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            rlp.topMargin = px(6)
            card.addView(row, rlp)

            val names = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val homeName = nameView()
            val awayName = nameView()
            names.addView(homeName, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            names.addView(awayName, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val nlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            nlp.topMargin = px(6)
            card.addView(names, nlp)

            val status = TextView(this@MainActivity).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_PX, 12f * unit)
                gravity = Gravity.CENTER
                setPadding(px(10), px(3), px(10), px(3))
            }
            val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            slp.topMargin = px(8)
            slp.gravity = Gravity.CENTER_HORIZONTAL
            card.addView(status, slp)

            return MatchVH(card, league, homeLogo, awayLogo, mid, homeName, awayName, status)
        }

        override fun onBindViewHolder(h: MatchVH, position: Int) {
            val m = items[position]
            h.league.text = m.league
            h.homeName.text = m.home
            h.awayName.text = m.away
            h.mid.text = if (m.live && m.score.isNotEmpty()) m.score else "VS"
            if (m.live) {
                h.status.text = if (m.minute.isNotEmpty()) "TRỰC TIẾP  " + m.minute else "TRỰC TIẾP"
                h.status.background = chipBackground(Color.parseColor("#D32F2F"))
            } else {
                h.status.text = if (m.time.isNotEmpty()) m.time else "Sắp diễn ra"
                h.status.background = chipBackground(Color.parseColor("#2A3650"))
            }
            loadLogo(h.homeLogo, m.homeLogo)
            loadLogo(h.awayLogo, m.awayLogo)
            h.card.setOnClickListener { openMatchUrl(m.url, position) }
            h.card.setOnLongClickListener { showSourcesDialog(m); true }
        }

        override fun getItemCount(): Int = items.size
    }

    private fun nameView(): TextView = TextView(this).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_PX, 14f * unit)
        gravity = Gravity.CENTER
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun cardBackground(): StateListDrawable {
        val focused = GradientDrawable().apply {
            cornerRadius = px(14).toFloat()
            setColor(Color.parseColor("#22324D"))
            setStroke(px(3), Color.parseColor("#4FC3F7"))
        }
        val normal = GradientDrawable().apply {
            cornerRadius = px(14).toFloat()
            setColor(Color.parseColor("#151C28"))
            setStroke(px(1), Color.parseColor("#26324A"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
    }

    private fun chipBackground(color: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = px(12).toFloat()
        setColor(color)
    }

    private fun loadLogo(iv: ImageView, url: String) {
        if (url.isBlank()) {
            iv.setImageDrawable(null)
            return
        }
        val model = GlideUrl(
            url,
            LazyHeaders.Builder().addHeader("Referer", homeUrl).addHeader("User-Agent", IMG_UA).build()
        )
        Glide.with(this).load(model).into(iv)
    }

    private fun showMessage(text: String, withButtons: Boolean) {
        msgText.text = text
        ballLoader.visibility = if (withButtons) View.GONE else View.VISIBLE
        if (withButtons) ballLoader.stop() else ballLoader.start()
        retryBtn.visibility = if (withButtons) View.VISIBLE else View.GONE
        origBtn.visibility = if (withButtons) View.VISIBLE else View.GONE
        msgBox.visibility = if (mode == Mode.GRID) View.VISIBLE else View.GONE
        if (withButtons && mode == Mode.GRID) retryBtn.requestFocus()
    }

    private fun hideMessage() {
        ballLoader.stop()
        msgBox.visibility = View.GONE
    }

    // ------------------------------------------------------------------ đọc danh sách trận từ trang chủ
    private fun reloadMatches() {
        scrapeGen++
        scrapeAttempt = 0
        scrapeEarly = false
        if (matchAdapter.itemCount == 0) {
            var cached: List<Match> = emptyList()
            try {
                val c = prefs().getString("ball_cache", null)
                if (!c.isNullOrBlank()) cached = parseMatches(JSONArray(c))
            } catch (e: Exception) {
            }
            if (cached.isNotEmpty()) {
                showMatches(cached)
                infoText.text = "Đang cập nhật..."
            } else {
                showMessage("Đang tải trận đấu…", false)
            }
        } else {
            infoText.text = "Đang cập nhật..."
        }
        scraper.stopLoading()
        scraper.loadUrl(homeUrl)
    }

    private fun runScrape(gen: Int) {
        if (gen != scrapeGen || scrapeJs.isEmpty()) return
        scraper.evaluateJavascript(scrapeJs) { raw ->
            if (gen == scrapeGen) onScraped(raw, gen)
        }
    }

    private fun onScraped(raw: String?, gen: Int) {
        var matches: List<Match> = emptyList()
        var dbg = ""
        var mArr: JSONArray? = null
        try {
            val v = JSONTokener(raw ?: "null").nextValue()
            if (v is String) {
                val o = JSONObject(v)
                mArr = o.optJSONArray("m")
                matches = parseMatches(mArr)
                dbg = o.optString("dbg")
            }
        } catch (e: Exception) {
            dbg = "lỗi đọc dữ liệu: " + e.message
        }
        scrapeAttempt++
        if (matches.isNotEmpty()) {
            showMatches(matches)
            try {
                if (mArr != null) prefs().edit().putString("ball_cache", mArr.toString()).apply()
            } catch (e: Exception) {
            }
            // đọc lại 2 lần nữa để bắt phần trang tải trễ
            if (scrapeAttempt < 3) ui.postDelayed({ runScrape(gen) }, 1500)
        } else if (scrapeAttempt < 14) {
            ui.postDelayed({ runScrape(gen) }, 700)
        } else {
            showError(dbg)
        }
    }

    private fun parseMatches(arr: JSONArray?): List<Match> {
        val list = ArrayList<Match>()
        if (arr == null) return list
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val provs = ArrayList<Pair<String, String>>()
            val pa = o.optJSONArray("p")
            if (pa != null) {
                for (j in 0 until pa.length()) {
                    val po = pa.optJSONObject(j) ?: continue
                    provs.add(Pair(po.optString("n"), po.optString("u")))
                }
            }
            list.add(
                Match(
                    url = o.optString("url"),
                    home = o.optString("home"),
                    away = o.optString("away"),
                    homeLogo = o.optString("hl"),
                    awayLogo = o.optString("al"),
                    league = o.optString("league"),
                    live = o.optBoolean("live"),
                    score = o.optString("score"),
                    minute = o.optString("minute"),
                    time = o.optString("time"),
                    providers = provs
                )
            )
        }
        return list
    }

    private fun showMatches(matches: List<Match>) {
        val firstTime = matchAdapter.itemCount == 0
        if (matches != matchAdapter.items) {
            matchAdapter.items = matches
            matchAdapter.notifyDataSetChanged()
        }
        hideMessage()
        val liveCount = matches.count { it.live }
        infoText.text = "${matches.size} trận  •  $liveCount đang diễn ra  •  " + hostOf(homeUrl)
        if (firstTime && mode == Mode.GRID) {
            lastPos = 0
            restoreFocus()
        }
    }

    private fun showError(dbg: String) {
        if (matchAdapter.itemCount > 0) {
            infoText.text = "Không cập nhật được, đang hiển thị danh sách cũ"
            return
        }
        val sb = StringBuilder()
        sb.append("Không đọc được danh sách trận từ ").append(homeHost).append(".\n\n")
        if (dbg.isNotEmpty()) sb.append("Chi tiết: ").append(dbg).append("\n\n")
        sb.append("Bấm nút Vàng trên remote hoặc chọn nút bên dưới.")
        showMessage(sb.toString(), true)
    }

    private fun restoreFocus() {
        if (matchAdapter.itemCount == 0) {
            if (msgBox.visibility == View.VISIBLE) retryBtn.requestFocus()
            return
        }
        val pos = lastPos.coerceIn(0, matchAdapter.itemCount - 1)
        recycler.post {
            val v = recycler.layoutManager?.findViewByPosition(pos)
            if (v != null) {
                v.requestFocus()
            } else {
                recycler.scrollToPosition(pos)
                recycler.post { recycler.layoutManager?.findViewByPosition(pos)?.requestFocus() }
            }
        }
    }

    private fun jumpTo(index: Int) {
        if (matchAdapter.itemCount == 0) return
        val i = index.coerceIn(0, matchAdapter.itemCount - 1)
        lastPos = i
        restoreFocus()
    }

    private fun focusedMatch(): Match? {
        val v = recycler.focusedChild ?: return null
        val pos = recycler.getChildAdapterPosition(v)
        return matchAdapter.items.getOrNull(pos)
    }

    private fun openMatchUrl(url: String, position: Int) {
        lastPos = position
        enterWeb(url, false)
    }

    private fun showSourcesDialog(m: Match) {
        if (m.providers.isEmpty()) {
            toast("Trận này chỉ có một nguồn phát")
            return
        }
        val names = ArrayList<String>()
        names.add("Nguồn chính (Xem ngay)")
        m.providers.forEach { names.add("Xem cùng " + it.first) }
        listDialog(m.home + " - " + m.away, names) { i ->
            if (i == 0) enterWeb(m.url, false) else enterWeb(m.providers[i - 1].second, false)
        }
    }

    // ------------------------------------------------------------------ chế độ xem trận (WebView)
    private fun enterWeb(url: String, orig: Boolean) {
        Uri.parse(url).host?.let { dynAllowed[it.lowercase()] = true }
        mode = Mode.WEB
        origSite = orig
        seekWarned = false
        gridLayer.visibility = View.GONE
        msgBox.visibility = View.GONE
        playerActive = false
        shell.visibility = View.GONE
        showHomeBtn()
        web.visibility = View.VISIBLE
        setCursor(isTv)
        setWebLoading(siteKind == "ball")
        web.loadUrl(url)
        web.requestFocus()
    }

    private fun leaveWeb() {
        playerActive = false
        if (siteKind == "movie") {
            goHome()
            return
        }
        mode = Mode.GRID
        origSite = false
        setCursor(false)
        web.loadUrl("about:blank")
        setWebLoading(false)
        web.visibility = View.GONE
        gridLayer.visibility = View.VISIBLE
        if (matchAdapter.itemCount == 0) {
            if (scrapeAttempt >= 6) {
                showError("")
            } else {
                msgBox.visibility = View.VISIBLE
            }
        }
        restoreFocus()
    }

    private fun setCursor(on: Boolean) {
        cursorOn = on
        val show = on && mode == Mode.WEB
        cursor.visibility = if (show) View.VISIBLE else View.GONE
        if (show) cursor.post { if (!cursor.placed) cursor.center() }
    }

    private fun onPlayerState(active: Boolean) {
        if (mode != Mode.WEB) return
        playerActive = active
        setCursor(!active && isTv)
        if (active && isTv) toast("OK: tạm dừng / phát   •   Trái, Phải: tua   •   Xanh dương: bật con trỏ")
    }

    inner class Bridge {
        @JavascriptInterface
        fun onPlayer(active: Boolean) {
            runOnUiThread { onPlayerState(active) }
        }
    }

    // ------------------------------------------------------------------ phím điều khiển
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        val down = e.action == KeyEvent.ACTION_DOWN
        val first = down && e.repeatCount == 0

        // Back: bấm nhanh = lùi một bước, giữ khoảng 1 giây = về màn hình chính của app
        if (code == KeyEvent.KEYCODE_BACK) {
            if (down) {
                if (e.repeatCount == 8 && !backLongHandled) {
                    backLongHandled = true
                    goHome()
                }
            } else if (e.action == KeyEvent.ACTION_UP) {
                if (backLongHandled) backLongHandled = false
                else if (!e.isCanceled) handleBack()
            }
            return true
        }
        if (mode == Mode.HOME) return super.dispatchKeyEvent(e)

        // phím màu và Menu: dùng ở mọi màn hình
        when (code) {
            KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_MENU -> {
                if (first) showMainMenu()
                return true
            }
            KeyEvent.KEYCODE_PROG_YELLOW -> {
                if (first) {
                    if (mode == Mode.WEB) web.reload() else reloadMatches()
                }
                return true
            }
            KeyEvent.KEYCODE_PROG_BLUE -> {
                if (first) {
                    if (mode == Mode.WEB) {
                        setCursor(!cursorOn)
                    } else {
                        val m = focusedMatch()
                        if (m != null) showSourcesDialog(m)
                    }
                }
                return true
            }
            KeyEvent.KEYCODE_PROG_RED -> {
                if (first && mode == Mode.WEB) leaveWeb()
                return true
            }
        }

        if (mode == Mode.GRID) {
            if (first && code >= KeyEvent.KEYCODE_1 && code <= KeyEvent.KEYCODE_9 && matchAdapter.itemCount > 0) {
                jumpTo(code - KeyEvent.KEYCODE_1)
                return true
            }
            return super.dispatchKeyEvent(e)
        }

        // ---- chế độ xem (WEB)
        when (code) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (first) togglePlay()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (first) seekBy(30)
                return true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (first) seekBy(-30)
                return true
            }
        }

        val playerKeys = !cursorOn || customView != null
        when (code) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (down) {
                    if (e.repeatCount == 0) {
                        okLongHandled = false
                    } else if (e.repeatCount == 12 && !okLongHandled) {
                        okLongHandled = true
                        showMainMenu()
                    }
                } else if (e.action == KeyEvent.ACTION_UP) {
                    if (!okLongHandled) {
                        if (playerKeys) togglePlay() else tapCursor()
                    }
                    okLongHandled = false
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!down) return true
                if (playerKeys) {
                    if (code == KeyEvent.KEYCODE_DPAD_LEFT) seekBy(-10)
                    if (code == KeyEvent.KEYCODE_DPAD_RIGHT) seekBy(10)
                } else {
                    moveCursor(code, e.repeatCount)
                }
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun moveCursor(code: Int, repeat: Int) {
        val step = (px(16) * (1f + minOf(repeat, 24) * 0.3f)).toInt()
        var dx = 0
        var dy = 0
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> dx = -step
            KeyEvent.KEYCODE_DPAD_RIGHT -> dx = step
            KeyEvent.KEYCODE_DPAD_UP -> dy = -step
            KeyEvent.KEYCODE_DPAD_DOWN -> dy = step
        }
        cursor.moveBy(dx, dy)
        val edge = px(24)
        if (dy < 0 && cursor.cy <= edge) web.scrollBy(0, -step * 2)
        if (dy > 0 && cursor.cy >= cursor.height - edge) web.scrollBy(0, step * 2)
    }

    private fun tapCursor() {
        if (!cursor.placed) return
        tapAt(cursor.cx, cursor.cy)
    }

    private fun tapAt(x: Float, y: Float) {
        val t = SystemClock.uptimeMillis()
        val d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
        d.source = InputDevice.SOURCE_TOUCHSCREEN
        web.dispatchTouchEvent(d)
        d.recycle()
        ui.postDelayed({
            val t2 = SystemClock.uptimeMillis()
            val u = MotionEvent.obtain(t, t2, MotionEvent.ACTION_UP, x, y, 0)
            u.source = InputDevice.SOURCE_TOUCHSCREEN
            web.dispatchTouchEvent(u)
            u.recycle()
        }, 60)
    }

    private fun togglePlay() {
        val js = "(function(){" + JS_FIND + ";var v=f(document);if(!v)return 'none';if(v.paused){v.play();}else{v.pause();}return 'ok';})()"
        web.evaluateJavascript(js) { r ->
            // không thấy thẻ video (trình phát nằm trong khung khác trang): bấm giữa màn hình
            if (r != null && r.contains("none")) tapAt(web.width / 2f, web.height / 2f)
        }
    }

    private fun seekBy(delta: Int) {
        val js = "(function(){" + JS_FIND + ";var v=f(document);if(!v||!isFinite(v.duration)||v.duration<=0)return 'none';" +
            "v.currentTime=Math.max(0,v.currentTime+(" + delta + "));return 'ok';})()"
        web.evaluateJavascript(js) { r ->
            if (r != null && r.contains("none") && !seekWarned) {
                seekWarned = true
                toast("Trận trực tiếp hoặc trình phát không cho tua")
            }
        }
    }

    // ------------------------------------------------------------------ WebView
    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(w: WebView) {
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.userAgentString = s.userAgentString.replace("; wv", "")
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
    }

    private fun newClient(isScraper: Boolean): WebViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val host = request.url.host ?: return null
            seenHosts.merge(host, 1) { a, b -> a + b }
            if (adBlock && adHostsReady && !isAllowedHost(host) && isAdHost(host)) {
                seenBlocked[host] = true
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url
            val scheme = u.scheme ?: return true
            // trang phim: khung phát nhúng (iframe) từ tên miền khác vẫn được tải
            if (siteKind == "movie" && !isScraper && !request.isForMainFrame && (scheme == "http" || scheme == "https")) return false
            if (scheme == "http" || scheme == "https") {
                if (isScraper || isAllowedHost(u.host)) return false
                toast("Đã chặn chuyển hướng: " + u.host)
                return true
            }
            return true   // chặn intent:, market:, ... (thường là quảng cáo mở app khác)
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            if (!isScraper && mode == Mode.WEB && url != null && url != "about:blank") setCursor(isTv)
        }

        override fun onPageFinished(view: WebView, url: String?) {
            super.onPageFinished(view, url)
            if (!isScraper) setWebLoading(false)
            if (url == "about:blank") {
                view.clearHistory()
                return
            }
            if (isScraper) {
                scrapeAttempt = 0
                val gen = scrapeGen
                ui.postDelayed({ runScrape(gen) }, 300)
            } else if (curInject().isNotEmpty()) {
                view.evaluateJavascript("window.__fchaiAdblock=$adBlock;${curInject()}", null)
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (isScraper && request.isForMainFrame) {
                scrapeGen++
                showError("lỗi mạng: " + error.description)
            }
        }
    }

    private fun setupWebViews() {
        configureShell()
        configure(scraper)
        scraper.settings.blockNetworkImage = true
        scraper.webViewClient = newClient(true)
        scraper.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress >= 60 && !scrapeEarly) {
                    scrapeEarly = true
                    val gen = scrapeGen
                    ui.postDelayed({ runScrape(gen) }, 300)
                }
            }
        }

        configure(web)
        web.addJavascriptInterface(Bridge(), "FchaiBridge")
        web.webViewClient = newClient(false)

        chrome = object : WebChromeClient() {
            // Cửa sổ mới (target=_blank, window.open): chỉ cho mở khi do người dùng bấm và đúng tên miền của trang
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                val temp = WebView(this@MainActivity)
                var done = false
                fun handle(url: String?) {
                    if (done || url == null || url == "about:blank") return
                    done = true
                    val host = Uri.parse(url).host
                    if (isAllowedHost(host)) web.post { web.loadUrl(url) } else toast("Đã chặn cửa sổ quảng cáo: $host")
                    temp.post { temp.destroy() }
                }
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        handle(r.url.toString())
                        return true
                    }

                    override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) {
                        handle(url)
                    }
                }
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = temp
                resultMsg.sendToTarget()
                return true
            }

            // Trình phát của trang tự mở toàn màn hình
            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                web.visibility = View.INVISIBLE
                cursor.visibility = View.GONE
            }

            override fun onHideCustomView() {
                val v = customView ?: return
                root.removeView(v)
                customView = null
                customCallback?.onCustomViewHidden()
                customCallback = null
                web.visibility = View.VISIBLE
                setCursor(cursorOn)
            }

            // chèn bộ dọn quảng cáo sớm, ngay khi trang tải được một phần
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (newProgress >= 80) setWebLoading(false)
                if (newProgress >= 15 && curInject().isNotEmpty() && mode == Mode.WEB) {
                    view.evaluateJavascript("window.__fchaiAdblock=$adBlock;${curInject()}", null)
                }
            }
        }
        web.webChromeClient = chrome
    }

    // ------------------------------------------------------------------ menu và hộp thoại
    private fun showMainMenu() {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()

        items.add("Về màn hình chính")
        acts.add { goHome() }

        if (siteKind == "ball") {
            items.add("Về danh sách trận")
            acts.add { if (mode == Mode.WEB) leaveWeb() else restoreFocus() }
        }

        items.add("Tải lại")
        acts.add { if (mode == Mode.WEB) web.reload() else reloadMatches() }

        if (siteKind == "movie") {
            items.add("Đổi địa chỉ trang phim  (đang dùng: $movieHost)")
            acts.add { showMovieAddressInput() }
        } else {
            items.add("Đổi địa chỉ web  (đang dùng: $homeHost)")
            acts.add { showAddressDialog() }
        }

        items.add("Chặn quảng cáo: " + (if (adBlock) "ĐANG BẬT (chọn để tắt)" else "ĐANG TẮT (chọn để bật)"))
        acts.add {
            adBlock = !adBlock
            toast(if (adBlock) "Đã bật chặn quảng cáo" else "Đã tắt chặn quảng cáo")
            if (mode == Mode.WEB) web.reload() else reloadMatches()
        }

        if (mode == Mode.WEB) {
            items.add("Con trỏ chuột: " + (if (cursorOn) "ĐANG BẬT (chọn để tắt)" else "ĐANG TẮT (chọn để bật)"))
            acts.add { setCursor(!cursorOn) }
        }

        if (siteKind == "ball") {
            items.add("Mở trang web gốc (dùng con trỏ)")
            acts.add { enterWeb(homeUrl, true) }
        }

        if (mode == Mode.WEB) {
            items.add("Phóng to trình phát")
            acts.add { web.evaluateJavascript("window.__fchaiEnter&&window.__fchaiEnter()", null) }
            items.add("Thu nhỏ (hình trong hình)")
            acts.add { enterPip() }
        }

        items.add("Xem tên miền đã tải (để gửi cho Claude)")
        acts.add { showHostsDialog() }

        items.add("Hướng dẫn phím")
        acts.add { showHelp() }

        listDialog("Menu", items) { i -> acts[i]() }
    }

    private fun listDialog(title: String, items: List<String>, onPick: (Int) -> Unit) {
        val ad = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextSize(TypedValue.COMPLEX_UNIT_PX, 17f * unit)
                v.setPadding(px(18), px(12), px(18), px(12))
                return v
            }
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setAdapter(ad) { d, which ->
                d.dismiss()
                onPick(which)
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun showAddressDialog() {
        val hist = loadHistory()
        val items = ArrayList<String>()
        items.add("Nhập địa chỉ mới...")
        items.add("Về mặc định ($HOME_URL)")
        hist.forEach { items.add(it) }
        listDialog("Đổi địa chỉ web (đang dùng: $homeUrl)", items) { i ->
            when (i) {
                0 -> showAddressInput()
                1 -> applyHomeUrl(HOME_URL)
                else -> applyHomeUrl(hist[i - 2])
            }
        }
    }

    private fun showAddressInput() {
        val et = EditText(this).apply {
            setText(homeUrl)
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 18f * unit)
            setPadding(px(20), px(14), px(20), px(14))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Nhập địa chỉ web mới")
            .setMessage("Ví dụ: tenmien.tv (không cần gõ https://)")
            .setView(et)
            .setPositiveButton("Lưu và mở") { _, _ -> applyHomeUrl(et.text.toString()) }
            .setNegativeButton("Hủy", null)
            .create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        et.requestFocus()
    }

    private fun applyHomeUrl(raw: String) {
        var u = raw.trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        val h = hostOf(u)
        if (h.isEmpty() || !h.contains('.')) {
            toast("Địa chỉ không hợp lệ")
            return
        }
        homeUrl = u
        homeHost = h
        prefs().edit().putString("home_url", u).apply()
        addHistory(u)
        toast("Đã đổi sang $h")
        if (mode == Mode.WEB) leaveWeb()
        matchAdapter.items = emptyList()
        matchAdapter.notifyDataSetChanged()
        reloadMatches()
    }

    private fun loadHistory(): List<String> {
        val s = prefs().getString("history", "") ?: ""
        return s.split("\n").filter { it.isNotBlank() }
    }

    private fun addHistory(u: String) {
        val list = ArrayList<String>()
        list.add(u)
        loadHistory().forEach { if (it != u && list.size < 8) list.add(it) }
        prefs().edit().putString("history", list.joinToString("\n")).apply()
    }

    private fun showHostsDialog() {
        val sb = StringBuilder("Tên miền đã tải (số lần | trạng thái):\n\n")
        seenHosts.entries.sortedByDescending { it.value }.take(40).forEach {
            sb.append(it.key).append("  |  ").append(it.value).append("  |  ")
                .append(if (seenBlocked.containsKey(it.key)) "CHẶN" else "cho phép").append('\n')
        }
        val tv = TextView(this).apply {
            text = sb.toString()
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 11f * unit)
            setPadding(px(20), px(12), px(20), px(12))
        }
        val sv = ScrollView(this).apply {
            isFocusable = true
            addView(tv)
        }
        AlertDialog.Builder(this)
            .setTitle("Tên miền đã tải")
            .setView(sv)
            .setPositiveButton("Đóng", null)
            .show()
    }

    private fun showHelp() {
        val body = "TRONG DANH SÁCH TRẬN\n" +
            "  Mũi tên: chọn trận     OK: xem trận\n" +
            "  Giữ OK hoặc nút Xanh dương: chọn nguồn phát khác\n" +
            "  Số 1-9: nhảy tới trận thứ mấy\n" +
            "  Vàng: tải lại danh sách     Xanh lá: menu\n\n" +
            "KHI ĐANG XEM\n" +
            "  OK: tạm dừng / phát     Trái, Phải: tua\n" +
            "  Xanh dương: bật / tắt con trỏ chuột\n" +
            "  Khi bật con trỏ: mũi tên di chuyển, OK để bấm\n" +
            "  Giữ OK hoặc Xanh lá: menu     Đỏ hoặc Back: về danh sách"
        val tv = TextView(this).apply {
            text = body
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 15f * unit)
            setPadding(px(24), px(16), px(24), px(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Hướng dẫn phím")
            .setView(tv)
            .setPositiveButton("Đóng", null)
            .show()
    }


    // ------------------------------------------------------------------ TV 3 TRONG 1: điều hướng chung
    private fun curInject(): String = if (siteKind == "movie") movieInjectJs else injectJs

    private fun handleBack() {
        when {
            customView != null -> chrome?.onHideCustomView()
            mode == Mode.WEB -> {
                if (siteKind == "movie") {
                    if (playerActive) {
                        web.evaluateJavascript("window.__fchaiExit&&window.__fchaiExit()", null)
                    } else if (web.canGoBack() && prevPageIsReal()) {
                        web.goBack()
                    } else {
                        goHome()
                    }
                } else {
                    if (origSite && web.canGoBack()) web.goBack() else leaveWeb()
                }
            }
            mode == Mode.GRID -> goHome()
            else -> shell.evaluateJavascript("window.tvBack?window.tvBack():false") { r ->
                if (r != "true") finish()
            }
        }
    }

    private fun prevPageIsReal(): Boolean {
        return try {
            val l = web.copyBackForwardList()
            val i = l.currentIndex
            i > 0 && (l.getItemAtIndex(i - 1).url ?: "about:blank") != "about:blank"
        } catch (e: Exception) {
            false
        }
    }

    private fun goHome() {
        if (customView != null) chrome?.onHideCustomView()
        mode = Mode.HOME
        origSite = false
        playerActive = false
        setCursor(false)
        setWebLoading(false)
        web.loadUrl("about:blank")
        web.visibility = View.GONE
        gridLayer.visibility = View.GONE
        msgBox.visibility = View.GONE
        homeBtn.visibility = View.GONE
        shell.visibility = View.VISIBLE
        shell.requestFocus()
        shell.evaluateJavascript("window.tvHome&&window.tvHome()", null)
        hideBars()
    }

    private fun enterBall() {
        siteKind = "ball"
        stopTvNative()
        mode = Mode.GRID
        origSite = false
        shell.visibility = View.GONE
        setWebLoading(false)
        web.visibility = View.GONE
        gridLayer.visibility = View.VISIBLE
        setCursor(false)
        showHomeBtn()
        reloadMatches()
        restoreFocus()
    }

    private fun enterMovie() {
        siteKind = "movie"
        stopTvNative()
        enterWeb(movieUrl, true)
    }

    private fun showHomeBtn() {
        homeBtn.visibility = View.VISIBLE
        homeBtn.alpha = 0.95f
        homeBtn.removeCallbacks(fadeHome)
        homeBtn.postDelayed(fadeHome, 3500)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN && homeBtn.visibility == View.VISIBLE) showHomeBtn()
        return super.dispatchTouchEvent(ev)
    }

    private fun enterPip() {
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        } catch (e: Exception) {
            toast("Không thu nhỏ được trên máy này")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (mode == Mode.WEB && siteKind == "ball") enterPip()
    }

    override fun onStop() {
        super.onStop()
        exo?.playWhenReady = false
    }

    override fun onStart() {
        super.onStart()
        if (mode == Mode.HOME) exo?.playWhenReady = true
    }

    private fun showMovieAddressInput() {
        val et = EditText(this).apply {
            setText(movieUrl)
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 18f * unit)
            setPadding(px(20), px(14), px(20), px(14))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Địa chỉ trang phim")
            .setMessage("Ví dụ: 500phim.net (không cần gõ https://)")
            .setView(et)
            .setPositiveButton("Lưu và mở") { _, _ -> applyMovieUrl(et.text.toString()) }
            .setNegativeButton("Hủy", null)
            .create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        et.requestFocus()
    }

    private fun applyMovieUrl(raw: String) {
        var u = raw.trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        val h = hostOf(u)
        if (h.isEmpty() || !h.contains('.')) {
            toast("Địa chỉ không hợp lệ")
            return
        }
        movieUrl = u
        movieHost = h
        prefs().edit().putString("movie_url", u).apply()
        toast("Đã đổi sang $h")
        enterWeb(u, true)
    }

    // ------------------------------------------------------------------ giao diện chính (shell) và phát kênh TV
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureShell() {
        val st = shell.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.allowFileAccess = true
        st.allowFileAccessFromFileURLs = true
        st.allowUniversalAccessFromFileURLs = true
        st.mediaPlaybackRequiresUserGesture = false
        st.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        shell.addJavascriptInterface(ShellBridge(), "Android")
        shell.webChromeClient = WebChromeClient()
        shell.webViewClient = WebViewClient()
        shell.loadUrl("file:///android_asset/index.html")
    }

    inner class ShellBridge {
        @JavascriptInterface
        fun openSite(kind: String) {
            runOnUiThread { if (kind == "movie") enterMovie() else enterBall() }
        }

        @JavascriptInterface
        fun tvPlay(url: String, referer: String, ua: String) {
            runOnUiThread { playTvNative(url, referer, ua) }
        }

        @JavascriptInterface
        fun tvStop() {
            runOnUiThread { stopTvNative() }
        }

        @JavascriptInterface
        fun tvCheck(json: String, gen: Int) {
            checkGen = gen
            val arr = JSONArray(json)
            val pool = java.util.concurrent.Executors.newFixedThreadPool(8)
            for (n in 0 until arr.length()) {
                val o = arr.getJSONObject(n)
                val idx = o.getInt("i")
                val u = o.getString("u")
                val ref = o.optString("ref")
                val ua = o.optString("ua")
                pool.execute {
                    val r = if (checkGen != gen) "huỷ" else probeStream(u, ref, ua)
                    runOnUiThread {
                        shell.evaluateJavascript(
                            "window.tvCheckRes&&window.tvCheckRes(" + idx + "," + JSONObject.quote(r) + "," + gen + ")", null
                        )
                    }
                }
            }
            pool.shutdown()
        }
    }

    @Volatile
    private var checkGen = 0

    private fun probeStream(url: String, ref: String, ua: String): String {
        val host = try { Uri.parse(url).host ?: "" } catch (e: Exception) { "" }
        val root = (if (url.startsWith("http://")) "http://" else "https://") + host + "/"
        var last = "lỗi"
        for (attempt in 0 until 4) {
            var conn: java.net.HttpURLConnection? = null
            try {
                var agent = IMG_UA
                var referer = ""
                var origin = ""
                when (attempt) {
                    0 -> {
                        referer = ref
                        if (ua.isNotBlank()) agent = ua
                    }
                    1 -> {
                        referer = root
                        origin = root.trimEnd('/')
                    }
                    2 -> agent = "VLC/3.0.18 LibVLC/3.0.18"
                    else -> agent = "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
                var cur = url
                var hops = 0
                var code: Int
                while (true) {
                    val c = java.net.URL(cur).openConnection() as java.net.HttpURLConnection
                    conn = c
                    c.connectTimeout = 7000
                    c.readTimeout = 7000
                    c.instanceFollowRedirects = false
                    if (referer.isNotBlank()) c.setRequestProperty("Referer", referer)
                    if (origin.isNotBlank()) c.setRequestProperty("Origin", origin)
                    c.setRequestProperty("User-Agent", agent)
                    code = c.responseCode
                    val loc = c.getHeaderField("Location")
                    if (code in 301..308 && loc != null && hops < 5) {
                        cur = java.net.URL(java.net.URL(cur), loc).toString()
                        hops++
                        c.disconnect()
                        continue
                    }
                    break
                }
                val c2 = conn!!
                if (code == 200) {
                    val buf = ByteArray(512)
                    val n = c2.inputStream.read(buf)
                    val head = if (n > 0) String(buf, 0, n, Charsets.ISO_8859_1) else ""
                    val ctype = (c2.contentType ?: "").lowercase()
                    val isTs = n > 0 && buf[0].toInt() == 0x47
                    if (head.contains("#EXTM3U") || head.contains("#EXT-X") || isTs ||
                        ctype.contains("mpegurl") || ctype.contains("mp2t") || ctype.startsWith("video/") || ctype.startsWith("audio/")) return "ok"
                    last = "không phải HLS"
                } else {
                    last = "HTTP $code"
                    if (code != 400 && code != 401 && code != 403) return last
                }
            } catch (e: Exception) {
                last = "lỗi mạng"
                return last
            } finally {
                try { conn?.disconnect() } catch (e: Exception) {}
            }
        }
        return last
    }

    private fun installCrashLog() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        val f = java.io.File(filesDir, "crash.txt")
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            try {
                f.writeText(android.util.Log.getStackTraceString(e).take(6000))
            } catch (x: Exception) {
            }
            prev?.uncaughtException(th, e)
        }
        if (f.exists()) {
            val msg = try { f.readText() } catch (x: Exception) { "" }
            f.delete()
            if (msg.isNotBlank()) {
                window.decorView.post {
                    try {
                        AlertDialog.Builder(this)
                            .setTitle("Lần trước app bị lỗi")
                            .setMessage(msg.take(1800))
                            .setPositiveButton("Đóng", null)
                            .setNeutralButton("Sao chép") { _, _ ->
                                try {
                                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("loi", msg))
                                    Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show()
                                } catch (x: Exception) {
                                }
                            }
                            .show()
                    } catch (x: Exception) {
                    }
                }
            }
        }
    }

    private fun setWebLoading(on: Boolean) {
        webLoading.visibility = if (on) View.VISIBLE else View.GONE
        ui.removeCallbacks(hideWebLoading)
        if (on) {
            webBall.start()
            ui.postDelayed(hideWebLoading, 15000)
        } else {
            webBall.stop()
        }
    }

    private fun playTvNative(url: String, referer: String, ua: String) {
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tvUrl = url
        tvRef = referer
        tvUa = ua
        tvAttempt = 0
        startTvAttempt()
    }

    private fun startTvAttempt() {
        releaseTv()
        val uri = Uri.parse(tvUrl)
        val siteRoot = (uri.scheme ?: "https") + "://" + (uri.host ?: "") + "/"
        val headers = HashMap<String, String>()
        var agent = IMG_UA
        when (tvAttempt) {
            0 -> {
                if (tvRef.isNotBlank()) headers["Referer"] = tvRef
                if (tvUa.isNotBlank()) agent = tvUa
            }
            1 -> {
                headers["Referer"] = siteRoot
                headers["Origin"] = siteRoot.trimEnd('/')
            }
            2 -> agent = "VLC/3.0.18 LibVLC/3.0.18"
            else -> agent = "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
        val factory = DefaultHttpDataSource.Factory()
            .setUserAgent(agent)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(8000)
            .setDefaultRequestProperties(headers)
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(factory))
            .build()
        p.setVideoTextureView(tvView)
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_BUFFERING) jsTv("loading", "")
                if (playbackState == Player.STATE_READY) jsTv("playing", "")
            }

            override fun onPlayerError(error: PlaybackException) {
                handleTvError(error)
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                fitTv(videoSize)
            }
        })
        try {
            p.setMediaItem(MediaItem.fromUri(tvUrl))
            p.playWhenReady = true
            p.prepare()
        } catch (e: Exception) {
            try { p.release() } catch (x: Exception) {}
            jsTv("error", "Định dạng không hỗ trợ")
            return
        }
        exo = p
        tvView.visibility = View.VISIBLE
        shell.setBackgroundColor(Color.TRANSPARENT)
    }

    private fun handleTvError(error: PlaybackException) {
        val c = error.cause
        val code = if (c is HttpDataSource.InvalidResponseCodeException) c.responseCode else 0
        val u = tvUrl
        val a = tvAttempt
        if ((code == 400 || code == 401 || code == 403) && a < 1) {
            ui.post {
                if (u == tvUrl && a == tvAttempt) {
                    tvAttempt = a + 1
                    startTvAttempt()
                }
            }
            return
        }
        jsTv("error", describeError(error) + " (đã thử " + (a + 1) + " cách)")
    }

    private fun releaseTv() {
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        exo?.release()
        exo = null
    }

    private fun stopTvNative() {
        releaseTv()
        tvView.visibility = View.GONE
        shell.setBackgroundColor(Color.parseColor("#0A0E15"))
    }

    private fun jsTv(state: String, msg: String) {
        shell.evaluateJavascript(
            "window.tvState&&window.tvState(" + JSONObject.quote(state) + "," + JSONObject.quote(msg) + ")", null
        )
    }

    private fun fitTv(vs: VideoSize) {
        if (vs.width == 0 || vs.height == 0) return
        val pw = root.width
        val ph = root.height
        if (pw == 0 || ph == 0) return
        val ar = vs.width * vs.pixelWidthHeightRatio / vs.height
        var w = pw
        var h = (pw / ar).toInt()
        if (h > ph) {
            h = ph
            w = (ph * ar).toInt()
        }
        tvView.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    private fun describeError(e: PlaybackException): String {
        val sb = StringBuilder(e.errorCodeName)
        sb.append(" @").append(Uri.parse(tvUrl).host ?: "")
        val c = e.cause
        if (c is HttpDataSource.InvalidResponseCodeException) {
            sb.append(" HTTP ").append(c.responseCode)
        } else if (c != null) {
            sb.append(": ").append(c.message ?: c.javaClass.simpleName)
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ tiện ích
    private fun prefs() = getSharedPreferences("xembongtv", Context.MODE_PRIVATE)

    private fun readAsset(name: String): String = try {
        assets.open(name).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        ""
    }

    private fun loadAdHosts() {
        Thread {
            val set = HashSet<String>()
            try {
                assets.open("ads_hosts.txt").bufferedReader().useLines { lines ->
                    lines.forEach { l ->
                        val t = l.trim()
                        if (t.isNotEmpty()) set.add(t)
                    }
                }
            } catch (e: Exception) {
            }
            adHosts = set
            adHostsReady = true
        }.start()
    }

    private fun hostOf(url: String): String =
        (Uri.parse(url).host ?: "").lowercase().removePrefix("www.")

    private fun isAllowedHost(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        if (homeHost.isNotEmpty() && (h == homeHost || h.endsWith(".$homeHost"))) return true
        if (dynAllowed.containsKey(h)) return true
        if (siteKind == "movie" && (h.contains("500phim") ||
                (movieHost.isNotEmpty() && (h == movieHost || h.endsWith(".$movieHost"))))) return true
        return h.contains("gavang") || EXTRA_ALLOWED_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    private fun isAdHost(host: String): Boolean {
        val set = adHosts
        var h = host.lowercase()
        while (true) {
            if (set.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
            if (!h.contains('.')) return false
        }
    }

    private fun px(v: Int): Int = (v * unit).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
